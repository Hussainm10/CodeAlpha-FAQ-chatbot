def load_faqs(filename):
    questions = []
    answers = []
    with open(filename, 'r', encoding='utf-8') as file:
        lines = file.readlines()
    # Remove any extra whitespace from lines and filter out empty lines
    lines = [line.strip() for line in lines if line.strip()]

    i = 0
    while i < len(lines):
        if lines[i].startswith('Q:'):
            question = lines[i][3:]  # Remove 'Q: ' prefix
            # Ensure there's a next line and it's an answer
            if i + 1 < len(lines) and lines[i + 1].startswith('A:'):
                answer = lines[i + 1][3:]  # Remove 'A: ' prefix
                questions.append(question)
                answers.append(answer)
                i += 2  # Move to the next pair
            else:
                # Handle the case where an answer is missing
                questions.append(question)
                answers.append("No answer available")
                i += 1
        else:
            # Skip lines that don't start with 'Q:' or 'A:'
            i += 1

    return questions, answers

def ask_questions(questions, answers):
    print("Ask a question or type 'exit' to quit.")
    while True:
        user_input = input("You: ").strip().lower()
        if user_input == 'exit':
            break
        # Find the best matching question
        for i, question in enumerate(questions):
            if user_input in question.lower():
                print(f"Answer: {answers[i]}")
                break
        else:
            print("Sorry, I don't know the answer to that question.")
# Load FAQ data
faqs_file = r"C:\Users\sg\Downloads\ChatBot for FAQ'S\FAQ_ai.txt"
questions, answers = load_faqs(faqs_file)

# Run the interactive Q&A session
ask_questions(questions, answers)
